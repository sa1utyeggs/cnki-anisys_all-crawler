create
    definer = root@localhost function mock_data() returns int
BEGIN
	DECLARE
		i INT DEFAULT 1;
		DECLARE
		j INT DEFAULT 0;
	WHILE i <= 10000 DO
	SET j = 0;
		WHILE j < 5 DO
		INSERT INTO goods_cover(good_id) VALUES(i);
		SET j = j + 1;
		END WHILE;
	SET i = i + 1;

	END WHILE;
	RETURN i;

END;

